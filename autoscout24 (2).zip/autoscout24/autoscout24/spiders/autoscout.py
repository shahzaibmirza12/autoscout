import csv
import json
from copy import deepcopy

import pymongo
import scrapy
from scrapy.utils.project import get_project_settings

settings = get_project_settings()


class AutoscoutSpider(scrapy.Spider):
    name = "autoscout"
    custom_settings = {
        "DOWNLOAD_HANDLERS": {
            "http": "scrapy_zyte_api.ScrapyZyteAPIDownloadHandler",
            "https": "scrapy_zyte_api.ScrapyZyteAPIDownloadHandler",
        },
        "DOWNLOADER_MIDDLEWARES": {
            "scrapy_zyte_api.ScrapyZyteAPIDownloaderMiddleware": 1000
        },
        "REQUEST_FINGERPRINTER_CLASS": "scrapy_zyte_api.ScrapyZyteAPIRequestFingerprinter",
        "TWISTED_REACTOR": "twisted.internet.asyncioreactor.AsyncioSelectorReactor",
        "ZYTE_API_KEY": "d5f9e0fa82c549929664cfe42fa440d2",  # Please enter your API Key here
        "ZYTE_API_TRANSPARENT_MODE": True,
        "ZYTE_API_EXPERIMENTAL_COOKIES_ENABLED": True,
    }

    start_urls = ['https://www.autoscout24.com/lst?atype=C&custtype=D&cy=D&desc=0&fregfrom=2019&fregto=2019&powertype=hp&search_id=528iyoo0ro&sort=standard&source=detailsearch&ustate=N%2CU&vatded=true']
    graphgl_url = "https://listing-search.api.autoscout24.com/graphql"
    payload = {
        "query": " query FetchTaxonomyModels($vehicleTypeId:String! $makeId:Int $include_en_GB:Boolean! $include_bg_BG:Boolean! $include_cs_CZ:Boolean! $include_de_AT:Boolean! $include_de_DE:Boolean! $include_es_ES:Boolean! $include_fr_BE:Boolean! $include_fr_FR:Boolean! $include_fr_LU:Boolean! $include_hr_HR:Boolean! $include_hu_HU:Boolean! $include_it_IT:Boolean! $include_nl_BE:Boolean! $include_nl_NL:Boolean! $include_pl_PL:Boolean! $include_ro_RO:Boolean! $include_ru_RU:Boolean! $include_sq_AL:Boolean! $include_sv_SE:Boolean! $include_tr_TR:Boolean! $include_uk_UA:Boolean!){taxonomy{filters{model{values(vehicleTypeId:$vehicleTypeId,makeId:$makeId){id name makeId modelLineId label{...LocalizedLabelConditionalInclude}}topModels(vehicleTypeId:$vehicleTypeId,makeId:$makeId){en_GB @include(if:$include_en_GB){...TopModel}bg_BG @include(if:$include_bg_BG){...TopModel}cs_CZ @include(if:$include_cs_CZ){...TopModel}de_AT @include(if:$include_de_AT){...TopModel}de_DE @include(if:$include_de_DE){...TopModel}es_ES @include(if:$include_es_ES){...TopModel}fr_BE @include(if:$include_fr_BE){...TopModel}fr_FR @include(if:$include_fr_FR){...TopModel}fr_LU @include(if:$include_fr_LU){...TopModel}hr_HR @include(if:$include_hr_HR){...TopModel}hu_HU @include(if:$include_hu_HU){...TopModel}it_IT @include(if:$include_it_IT){...TopModel}nl_BE @include(if:$include_nl_BE){...TopModel}nl_NL @include(if:$include_nl_NL){...TopModel}pl_PL @include(if:$include_pl_PL){...TopModel}ro_RO @include(if:$include_ro_RO){...TopModel}ru_RU @include(if:$include_ru_RU){...TopModel}sq_AL @include(if:$include_sq_AL){...TopModel}sv_SE @include(if:$include_sv_SE){...TopModel}tr_TR @include(if:$include_tr_TR){...TopModel}uk_UA @include(if:$include_uk_UA){...TopModel}}}modelLine{values(vehicleTypeId:$vehicleTypeId,makeId:$makeId){id name makeId vehicleTypeId label{...LocalizedLabelConditionalInclude}}}}}}fragment LocalizedLabelConditionalInclude on TaxonomyLocalizedMessage{en_GB @include(if:$include_en_GB)bg_BG @include(if:$include_bg_BG)cs_CZ @include(if:$include_cs_CZ)de_AT @include(if:$include_de_AT)de_DE @include(if:$include_de_DE)es_ES @include(if:$include_es_ES)fr_BE @include(if:$include_fr_BE)fr_FR @include(if:$include_fr_FR)fr_LU @include(if:$include_fr_LU)hr_HR @include(if:$include_hr_HR)hu_HU @include(if:$include_hu_HU)it_IT @include(if:$include_it_IT)nl_BE @include(if:$include_nl_BE)nl_NL @include(if:$include_nl_NL)pl_PL @include(if:$include_pl_PL)ro_RO @include(if:$include_ro_RO)ru_RU @include(if:$include_ru_RU)sq_AL @include(if:$include_sq_AL)sv_SE @include(if:$include_sv_SE)tr_TR @include(if:$include_tr_TR)uk_UA @include(if:$include_uk_UA)}fragment TopModel on TaxonomyTopModelValue{makeId values{id name}}",
        "variables": {
            "locale": "en_GB",
            "vehicleTypeId": "C",
            "makeId": 29,
            "include_en_GB": True,
            "include_bg_BG": False,
            "include_cs_CZ": False,
            "include_de_AT": False,
            "include_de_DE": False,
            "include_es_ES": False,
            "include_fr_BE": False,
            "include_fr_FR": False,
            "include_fr_LU": False,
            "include_hr_HR": False,
            "include_hu_HU": False,
            "include_it_IT": False,
            "include_nl_BE": False,
            "include_nl_NL": False,
            "include_pl_PL": False,
            "include_ro_RO": False,
            "include_ru_RU": False,
            "include_sq_AL": False,
            "include_sv_SE": False,
            "include_tr_TR": False,
            "include_uk_UA": False
        },
        "operationName": "FetchTaxonomyModels"
    }
    headers = {
        'authority': 'listing-search.api.autoscout24.com',
        'accept': '*/*',
        'accept-language': 'en-US,en;q=0.9',
        'authorization': 'Basic YXMyNC1zZWFyY2gtZnVubmVsOnZucmZiYkJqSTMyT2wxV2thNnVOSFJwM0VZbjRkag==',
        'cache-control': 'no-cache',
        'content-type': 'application/json',
        'origin': 'https://www.autoscout24.com',
        'pragma': 'no-cache',
        'referer': 'https://www.autoscout24.com/',
        'sec-ch-ua': '"Not A(Brand";v="99", "Google Chrome";v="121", "Chromium";v="121"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        # 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36'
    }

    list_api = 'https://www.autoscout24.com/_next/data/{}/lst/{}/{}.json?atype=C&custtype=D&cy=D&damaged_listing=exclude&desc=0&fregfrom={}&fregto={}&ocs_listing=include&page={}&powertype=hp&sort=standard&source=listpage_pagination&ustate=N%2CU&vatded=true&slug={}&slug={}'
    build_id = ''
    def __init__(self):
        connection = pymongo.MongoClient(
            settings.get('MONGODB_CONNECTION'),
        )
        db = connection[settings.get('MONGODB_DB')]
        self.collection = db[settings.get('MONGODB_COLLECTION')]

    def parse(self, response):
        json_data = json.loads(response.css('#__NEXT_DATA__::text').get('{}'))
        self.build_id = json_data.get('buildId')

        for makes in list(json_data.get('props', {}).get('pageProps', {}).get('taxonomy', {}).get('makes', {}).keys()):
            make_json = json_data.get('props', {}).get('pageProps', {}).get('taxonomy', {}).get('makes', {}).get(makes)
            payload = deepcopy(self.payload)
            payload['variables']['makeId'] = make_json.get('value')
            yield scrapy.Request(
                url=self.graphgl_url,
                method='POST',
                body=json.dumps(payload),
                callback=self.parse_models,
                headers=self.headers,
                meta={'make_id': make_json.get('value'), 'make_name': make_json.get('label')}
            )

    def parse_models(self, response):
        make_id = response.meta['make_id']
        make_name = response.meta['make_name']
        json_data = response.json()
        for model in json_data.get('data', {}).get('taxonomy', {}).get('filters', {}).get('model', {}).get('values', []):
            print(model.get('name').lower().replace(' ', '-'))
            for year_car in ['2019', '2020', '2021', '2022', '2023', '2024']:
                yield scrapy.Request(
                    url=self.list_api.format(self.build_id,
                                             make_name.lower().replace(' ', '-'),
                                             model.get('name').lower().replace(' ', '-'),
                                             year_car,
                                             year_car,
                                             1,
                                             make_name.lower().replace(' ', '-'),
                                             model.get('name').lower().replace(' ', '-')),
                    callback=self.parse_listing,
                    headers=self.headers,
                    meta={'page': 1, 'make': make_name.lower().replace(' ', '-'), 'model': model.get('name').lower().replace(' ', '-'), 'year_car':year_car}
                )

    def parse_listing(self, response):
        json_data = response.json()
        year_car = response.meta['year_car']
        page = response.meta['page']
        make = response.meta['make']
        model = response.meta['model']

        for listing_dict in json_data.get('pageProps', {}).get('listings', []):
            query = {"Unique_ID": listing_dict.get('id')}
            result = self.collection.find_one(query)
            if result:
                print("Data with Unique_ID '{}' exists.".format(listing_dict.get('id')))
            else:
                yield scrapy.Request(url=response.urljoin(listing_dict.get('url')),
                                     callback=self.parse_details)

        if page < json_data.get('pageProps', {}).get('numberOfPages', 0):
            yield scrapy.Request(
                url=self.list_api.format(self.build_id, make, model,
                                         year_car,
                                         year_car,
                                         page + 1,
                                         make,
                                         model),
                callback=self.parse_listing,
                meta={'page': page + 1, 'make': make,
                      'model': model, 'year_car': year_car}
            )

    def parse_details(self, response):
        json_data = json.loads(response.css('#__NEXT_DATA__::text').get('{}'))
        product_dict = json_data.get('props', {}).get('pageProps', {}).get('listingDetails', {})
        fuel = []
        if product_dict.get('vehicle', {}).get('fuelConsumptionCombined'):
            fuel.append(product_dict.get('vehicle', {}).get('fuelConsumptionCombined', {}).get('formatted'))

        if product_dict.get('vehicle', {}).get('fuelConsumptionUrban'):
            fuel.append(product_dict.get('vehicle', {}).get('fuelConsumptionUrban', {}).get('formatted'))

        if product_dict.get('vehicle', {}).get('fuelConsumptionExtraUrban'):
            fuel.append(product_dict.get('vehicle', {}).get('fuelConsumptionExtraUrban', {}).get('formatted'))

        yield {
            'Unique_ID': product_dict.get('id'),
            'brand': product_dict.get('vehicle', {}).get('make'),
            'model': product_dict.get('vehicle', {}).get('model'),
            'title': product_dict.get('vehicle', {}).get('modelVersionInput'),
            'price': product_dict.get('price', {}).get('public', {}).get('priceRaw'),
            'milage': product_dict.get('vehicle', {}).get('mileageInKmRaw'),
            'gearbox': product_dict.get('vehicle', {}).get('transmissionType'),
            'registration': product_dict.get('vehicle', {}).get('firstRegistrationDate'),
            'power': f"{product_dict.get('vehicle', {}).get('powerInKw')} ({product_dict.get('vehicle', {}).get('powerInHp')})",
            'Basicdata': {
                'Body': product_dict.get('vehicle', {}).get('bodyType'),
                'Type': product_dict.get('vehicle', {}).get('type'),
                'Drivetrain': product_dict.get('vehicle', {}).get('driveTrain'),
                'Seats': product_dict.get('vehicle', {}).get('numberOfSeats'),
                'Doors': product_dict.get('vehicle', {}).get('numberOfDoors'),
                'Offernumber': product_dict.get('identifier', {}).get('offerReference'),
                'Modelcode': product_dict.get('vehicle', {}).get('hsnTsn')
            },
            'vehiclehistory': {
                'Mileage': product_dict.get('vehicle', {}).get('mileageInKm'),
                'Firstregistration': product_dict.get('vehicle', {}).get('firstRegistrationDate'),
                'Previousowner': product_dict.get('vehicle', {}).get('noOfPreviousOwners'),
                'Fullservicehistory': product_dict.get('vehicle', {}).get('hasFullServiceHistory'),
                'Nonsmokervehicle': product_dict.get('vehicle', {}).get('nonSmoking')
            },
            'TechnicalData': {
                'Power': f"{product_dict.get('vehicle', {}).get('powerInKw')} ({product_dict.get('vehicle', {}).get('powerInHp')})",
                'Nonsmokervehicle': product_dict.get('vehicle', {}).get('nonSmoking'),
                'Gearbox': product_dict.get('vehicle', {}).get('transmissionType'),
                'Enginesize': product_dict.get('vehicle', {}).get('displacementInCCM'),
                'Cylinders': product_dict.get('vehicle', {}).get('cylinders'),
                'Emptyweight': product_dict.get('vehicle', {}).get('weight')

            },
            'energyconsumption': {
                'Fueltype': product_dict.get('vehicle', {}).get('fuelCategory', {}).get('formatted'),
                'Fuelconsumption': fuel,
                'emissions': product_dict.get('vehicle', {}).get('co2emissionInGramPerKmWithFallback', {}).get('formatted')if product_dict.get('vehicle', {}).get('co2emissionInGramPerKmWithFallback') else None,
                'Energyefficiencyclass': product_dict.get('vehicle', {}).get('environmentPkwEnVKV', {}).get('formatted') if product_dict.get('vehicle', {}).get('environmentPkwEnVKV') else None,
                'Emissionclass': product_dict.get('vehicle', {}).get('environmentEuDirective', {}).get('formatted')if product_dict.get('vehicle', {}).get('environmentEuDirective') else None,
                'Emissionssticker': product_dict.get('vehicle', {}).get('environmentBImSchV35', {}).get('formatted')if product_dict.get('vehicle', {}).get('environmentBImSchV35') else None
            },
            'Equipment': {
                'ComfortConvenience': [comf.get('id') for comf in product_dict.get('vehicle', {}).get('equipment', {}).get('comfortAndConvenience', [])],
                'entertainmentAndMedia': [comf.get('id') for comf in
                                       product_dict.get('vehicle', {}).get('equipment', {}).get('entertainmentAndMedia',
                                                                                                [])],
                'extras': [comf.get('id') for comf in
                                       product_dict.get('vehicle', {}).get('equipment', {}).get('extras', [])],
                'safetyAndSecurity': [comf.get('id') for comf in
                                       product_dict.get('vehicle', {}).get('equipment', {}).get('safetyAndSecurity', [])]
            },
            'colourandupholstery':{
                'Colour': product_dict.get('vehicle', {}).get('bodyColor'),
                'Manufacturercolour': product_dict.get('vehicle', {}).get('bodyColorOriginal'),
                'Paint': product_dict.get('vehicle', {}).get('paintType'),
                'Upholstery': product_dict.get('vehicle', {}).get('upholstery')
            },
            'Images': product_dict.get('images', []),
            'Product_URL': response.url
        }

